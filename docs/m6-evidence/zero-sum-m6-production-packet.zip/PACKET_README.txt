ZERO SUM M6: OPEN/FORK production-input packet, not artwork.
Start with production/m6-open-fork/README.md and pilot.json.
No generated source, numeric actual ROI, accepted master or live binding is included.
Existing images retain their original paths and are labeled provisional references.
Rejected creative boards are not included. No license is inferred from this archive.
Approved screenplay files retain historical draft warnings; owner authorization is recorded in the M6 brief and current repository. Source words are unchanged.
The two-image instructions and nine bilingual panel excerpts are self-contained.
Historical/repository QA links in source documents refer to the full repository and may not be included here. The M5 specification is included as an unchanged reference, not permission for its other 19 masters.
The read-only Python inspector requires the existing Pillow library; run from this archive root. No credentials, runtime app, production artwork or paid provider invocation is included.
MANIFEST.json records every payload digest. Preserve generation/cost/terms receipts and get owner art approval before activation.
